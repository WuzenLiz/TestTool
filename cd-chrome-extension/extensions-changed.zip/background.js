chrome.browserAction.onClicked.addListener(function (tab) {
  chrome.tabs.executeScript({
    // code: 'document.body.style.backgroundColor="red"',
    file: "content.js",
  });
});
