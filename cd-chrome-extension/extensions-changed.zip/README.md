# make-it-rainbow-chrome-extension
A chrome extension that changes the color of your webpage to a random color

This repository is created for the tutorial written on https://dev.to/jhotterbeekx/let-s-build-a-chrome-extension-3n3k